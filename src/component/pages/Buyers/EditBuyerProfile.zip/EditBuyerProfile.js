import React, { useEffect, useState } from "react";
import BuyerHeader from "../../partials/Layouts/BuyerHeader";
import Footer from "../../partials/Layouts/Footer";
import Select from "react-select";
import axios from "axios";
import { useForm, Controller } from "react-hook-form";
import { useAuth } from "../../../hooks/useAuth";
import { useFormError } from "../../../hooks/useFormError";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
const EditBuyerProfile = () => {
  const {
    register,
    handleSubmit,
    control,
    formState: { errors },
  } = useForm();
  const { getTokenData, setLogout } = useAuth();
  const [buyerData, setBuyerData] = useState({});
  const { setErrors, renderFieldError } = useFormError();

  const [state, setState] = useState("");
  const [city, setCity] = useState("");
  const [marketPreference, setMarketPreference] = useState("");
  const [contactPreference, setContactPreference] = useState("");
  const [propertyType, setPropertyType] = useState("");
  const [purchaseMethods, setPurchaseMethods] = useState("");
  const [parking, setParking] = useState("");
  const [buyerType, setBuyerType] = useState("");
  const [locationFlaws, setLocationFlaws] = useState("");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");

  /* min max value states start */
  const [bedRoomMin, setBedRoomMin] = useState("");
  const [bedRoomMax, setBedRoomMax] = useState("");
  const [bathMin, setBathMin] = useState("");
  const [bathMax, setBathMax] = useState("");
  const [sqFtMin, setSqFtMin] = useState("");
  const [sqFtMax, setSqFtMax] = useState("");
  const [lotSizesqFtMin, setlotSizesqFtMin] = useState("");
  const [lotSizesqFtMax, setlotSizesqFtMax] = useState("");
  const [storiesMin, setStoriesMin] = useState("");
  const [storiesMax, setStoriesMax] = useState("");
  const [priceMin, setPriceMin] = useState("");
  const [priceMax, setPriceMax] = useState("");
  /* min max value states end */

  const handleCustum = (e, name) => {};

  const fetchBuyerData = async () => {
    try {
      const apiUrl = process.env.REACT_APP_API_URL;
      let headers = {
        Accept: "application/json",
        Authorization: "Bearer " + getTokenData().access_token,
      };
      let response = await axios.get(apiUrl + "edit-buyer", { headers });
      setBuyerData(response.data.buyer);
    } catch (error) {}
  };

  const fetchData = async () => {
    try {
      const apiUrl = process.env.REACT_APP_API_URL;
      let headers = {
        Accept: "application/json",
        Authorization: "Bearer " + getTokenData().access_token,
      };
      let response = await axios.get(
        apiUrl + "edit-buyer-form-element-values",
        { headers }
      );
      console.log(response.data.result);
      if (response.data.status) {
        setState(response.data.result.states);
        setMarketPreference(response.data.result.market_preferances);
        setContactPreference(response.data.result.contact_preferances);
        setPropertyType(response.data.result.property_types);
        setPurchaseMethods(response.data.result.purchase_methods);
        setParking(response.data.result.parking_values);
        setBuyerType(response.data.result.buyer_types);
        setLocationFlaws(response.data.result.location_flaws);
        console.log(response.data.result, "fetchh");
      }
    } catch (error) {}
  };
  useEffect(() => {
    fetchBuyerData();
    fetchData();
  }, []);

  const submitBuyerForm = async (data, e) => {
    e.preventDefault();
  };
  return (
    <>
      <BuyerHeader />
      <section className="main-section position-relative pt-4 pb-120">
        <div className="container position-relative">
          <div className="back-block">
            <div className="row">
              <div className="col-12 col-sm-4 col-md-4 col-lg-4">
                <a href="#" className="back">
                  <svg
                    width="16"
                    height="12"
                    viewBox="0 0 16 12"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M15 6H1"
                      stroke="#0A2540"
                      strokeWidth="1.5"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                    <path
                      d="M5.9 11L1 6L5.9 1"
                      stroke="#0A2540"
                      strokeWidth="1.5"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                  Back
                </a>
              </div>
              <div className="col-12 col-sm-4 col-md-4 col-lg-4">
                <h6 className="center-head text-center mb-0">Edit Profile</h6>
              </div>
            </div>
          </div>
          <div className="card-box">
            <div className="row">
              <div className="col-12 col-lg-4">
                <form className="form-container">
                  <div className="outer-heading text-center">
                    <h3 className="mb-0">Edit Profile Picture </h3>
                  </div>
                  <div className="upload-photo">
                    <div className="containers">
                      <div className="imageWrapper">
                        <img
                          className="image img-fluid"
                          src="assets/images/avtar-big.png"
                        />
                      </div>
                    </div>
                    <button className="file-upload">
                      <input type="file" className="file-input" />
                      upload Your Image
                    </button>
                  </div>
                </form>
              </div>
              <div className="col-12 col-lg-8">
                <div className="card-box-inner">
                  <h3>Edit Profile</h3>
                  <p>Lorem Ipsum is simply dummy text of the</p>
                  <form
                    className="form-container"
                    method="post"
                    onSubmit={handleSubmit(submitBuyerForm)}
                  >
                    <div className="card-box-blocks">
                      <div className="row">
                        <div className="col-12 col-sm-6 col-md-6 col-lg-6">
                          <label>
                            First Name<span>*</span>
                          </label>
                          <div className="form-group">
                            <input
                              type="text"
                              name="first_name"
                              className="form-control"
                              placeholder="First Name"
                              defaultValue={buyerData.first_name}
                              {...register("first_name", {
                                required: "Last Name is required",
                                validate: {
                                  maxLength: (v) =>
                                    v.length <= 50 ||
                                    "The Last Name should have at most 50 characters",
                                  matchPattern: (v) =>
                                    /^[a-zA-Z\s]+$/.test(v) ||
                                    "Last Name can not include number or special character",
                                },
                              })}
                            />
                            {errors.first_name && (
                              <p className="error">
                                {errors.first_name?.message}
                              </p>
                            )}
                            {renderFieldError("first_name")}
                          </div>
                        </div>
                        <div className="col-12 col-sm-6 col-md-6 col-lg-6">
                          <label>
                            last Name<span>*</span>
                          </label>
                          <div className="form-group">
                            <input
                              type="text"
                              name="last_name"
                              className="form-control"
                              placeholder="last Name"
                              defaultValue={buyerData.last_name}
                              {...register("last_name", {
                                required: "Last Name is required",
                                validate: {
                                  maxLength: (v) =>
                                    v.length <= 50 ||
                                    "The Last Name should have at most 50 characters",
                                  matchPattern: (v) =>
                                    /^[a-zA-Z\s]+$/.test(v) ||
                                    "Last Name can not include number or special character",
                                },
                              })}
                            />
                            {errors.last_name && (
                              <p className="error">
                                {errors.last_name?.message}
                              </p>
                            )}
                            {renderFieldError("last_name")}
                          </div>
                        </div>
                        <div className="col-12 col-sm-6 col-md-6 col-lg-6">
                          <label>
                            Email<span>*</span>
                          </label>
                          <div className="form-group">
                            <input
                              type="email"
                              className="form-control"
                              placeholder="Email"
                              defaultValue={buyerData.email}
                              disabled
                            />
                          </div>
                        </div>
                        <div className="col-12 col-sm-6 col-md-6 col-lg-6">
                          <label>
                            Phone Number<span>*</span>
                          </label>
                          <div className="form-group">
                            <input
                              type="text"
                              name="phone"
                              className="form-control"
                              placeholder="Phone Number"
                              defaultValue={buyerData.phone}
                              {...register("phone", {
                                required: "Phone Number is required",
                                validate: {
                                  matchPattern: (v) =>
                                    /^[0-9]\d*$/.test(v) ||
                                    "Please enter valid phone number",
                                  maxLength: (v) =>
                                    (v.length <= 15 && v.length >= 5) ||
                                    "The phone number should be more than 4 digit and less than equal 15",
                                },
                              })}
                            />
                          </div>
                        </div>
                        <div className="col-12 col-sm-6 col-md-6 col-lg-6">
                          <label>
                            State<span>*</span>
                          </label>
                          <div className="form-group">
                            <Controller
                              control={control}
                              name="state"
                              rules={{ required: "State is required" }}
                              render={({
                                field: { value, onChange, name },
                              }) => (
                                <Select
                                  options={state}
                                  name={name}
                                  //value={state}
                                  closeMenuOnSelect={false}
                                  isClearable={true}
                                  className="select"
                                  placeholder="Select State"
                                  onChange={(e) => {
                                    onChange(e);
                                    handleCustum(e, "state");
                                  }}
                                  isMulti
                                />
                              )}
                            />
                            {errors.state && (
                              <p className="error">{errors.state?.message}</p>
                            )}
                            {renderFieldError("state")}
                          </div>
                        </div>
                        <div className="col-12 col-sm-6 col-md-6 col-lg-6">
                          <label>
                            City<span>*</span>
                          </label>
                          <div className="form-group">
                            <Controller
                              control={control}
                              name="city"
                              rules={{ required: "City is required" }}
                              render={({
                                field: { value, onChange, name },
                              }) => (
                                <Select
                                  options={city}
                                  name={name}
                                  value={city}
                                  isClearable={true}
                                  closeMenuOnSelect={false}
                                  className="select"
                                  placeholder="Select City"
                                  onChange={(e) => {
                                    onChange(e);
                                  }}
                                  isMulti
                                />
                              )}
                            />
                            {errors.city && (
                              <p className="error">{errors.city?.message}</p>
                            )}
                            {renderFieldError("city")}
                          </div>
                        </div>
                        <div className="col-12 col-sm-6 col-md-6 col-lg-4">
                          <label>Company/LLC</label>
                          <div className="form-group">
                            <input
                              type="text"
                              name="company_name"
                              className="form-control"
                              placeholder="Enter Company/LLC"
                              defaultValue={buyerData.company_name}
                              {...register("company_name", {
                                required: "Company/LLC is required",
                                validate: {
                                  maxLength: (v) =>
                                    v.length <= 50 ||
                                    "The Company/LLC should have at most 50 characters",
                                },
                              })}
                            />
                            {errors.company_name && (
                              <p className="error">
                                {errors.company_name?.message}
                              </p>
                            )}
                            {renderFieldError("company_name")}
                          </div>
                        </div>
                        <div className="col-12 col-sm-6 col-md-6 col-lg-4">
                          <label>MLS Status</label>
                          <div className="form-group">
                            <Controller
                              control={control}
                              name="market_preferance"
                              rules={{ required: "State is required" }}
                              render={({
                                field: { value, onChange, name },
                              }) => (
                                <Select
                                  options={marketPreference}
                                  name={name}
                                  //value={state}
                                  closeMenuOnSelect={false}
                                  isClearable={true}
                                  className="select"
                                  placeholder="Select State"
                                  onChange={(e) => {
                                    onChange(e);
                                    handleCustum(e, "state");
                                  }}
                                  isMulti
                                />
                              )}
                            />
                            {errors.market_preferance && (
                              <p className="error">
                                {errors.market_preferance?.message}
                              </p>
                            )}

                            {renderFieldError("market_preferance")}
                          </div>
                        </div>
                        <div className="col-12 col-sm-6 col-md-6 col-lg-4">
                          <label>Contact Preference</label>
                          <div className="form-group">
                            <Controller
                              control={control}
                              name="mls_status"
                              rules={{ required: "State is required" }}
                              render={({
                                field: { value, onChange, name },
                              }) => (
                                <Select
                                  options={contactPreference}
                                  name={name}
                                  //value={state}
                                  closeMenuOnSelect={false}
                                  isClearable={true}
                                  className="select"
                                  placeholder="Select Contact Preference"
                                  onChange={(e) => {
                                    onChange(e);
                                    handleCustum(e, "contact_preferance");
                                  }}
                                  isMulti
                                />
                              )}
                            />
                            {errors.contact_preferance && (
                              <p className="error">
                                {errors.contact_preferance?.message}
                              </p>
                            )}
                            {renderFieldError("contact_preferance")}
                          </div>
                        </div>
                        <div className="col-12 col-lg-6">
                          <div className="form-group">
                            <label>
                              Property Type<span>*</span>
                            </label>
                            <div className="form-group">
                              <Controller
                                control={control}
                                name="property_type"
                                rules={{
                                  required: "Property Type is required",
                                }}
                                render={({
                                  field: { value, onChange, name },
                                }) => (
                                  <Select
                                    options={propertyType}
                                    name={name}
                                    //value={state}
                                    closeMenuOnSelect={false}
                                    isClearable={true}
                                    className="select"
                                    placeholder="Select State"
                                    onChange={(e) => {
                                      onChange(e);
                                      handleCustum(e, "state");
                                    }}
                                    isMulti
                                  />
                                )}
                              />
                              {errors.property_type && (
                                <p className="error">
                                  {errors.property_type?.message}
                                </p>
                              )}

                              {renderFieldError("property_type")}
                            </div>
                          </div>
                        </div>

                        <div className="col-12 col-lg-6">
                          <label>
                            Purchase Method<span>*</span>
                          </label>
                          <div className="form-group">
                            <Controller
                              control={control}
                              name="purchase_method"
                              rules={{
                                required: "Purchase Method is required",
                              }}
                              render={({
                                field: { value, onChange, name },
                              }) => (
                                <Select
                                  options={purchaseMethods}
                                  name={name}
                                  //value={state}
                                  closeMenuOnSelect={false}
                                  isClearable={true}
                                  className="select"
                                  placeholder="Select Purchase Method"
                                  onChange={(e) => {
                                    onChange(e);
                                    handleCustum(e, "purchase_method");
                                  }}
                                  isMulti
                                />
                              )}
                            />
                            {errors.purchase_method && (
                              <p className="error">
                                {errors.purchase_method?.message}
                              </p>
                            )}

                            {renderFieldError("purchase_method")}
                          </div>
                        </div>
                        <div className="col-12 col-sm-6 col-md-6 col-lg-4">
                          <label>
                            Bedroom (min)<span>*</span>
                          </label>
                          <div className="form-group">
                            <input
                              type="text"
                              name="bedroom_min"
                              className="form-control"
                              placeholder="Bedroom (min)"
                              defaultValue={buyerData.bedroom_min}
                              {...register("bedroom_min", {
                                onChange: (e) => {
                                  setBedRoomMin(e.target.value);
                                },
                                required: "Bedroom (min) is required",
                                validate: {
                                  matchPattern: (v) =>
                                    /^[0-9]\d*$/.test(v) ||
                                    "Please enter valid number",
                                  maxLength: (v) =>
                                    v.length <= 10 ||
                                    "The digit should be less than equal 10",
                                  positiveNumber: (v) =>
                                    parseFloat(v) <= bedRoomMax ||
                                    "The Bedroom (min) should be less than or equal Bedroom (max)",
                                },
                              })}
                            />
                            {errors.bedroom_min && (
                              <p className="error">
                                {errors.bedroom_min?.message}
                              </p>
                            )}

                            {renderFieldError("bedroom_min")}
                          </div>
                        </div>
                        <div className="col-12 col-sm-6 col-md-6 col-lg-4">
                          <label>
                            Bedroom (max)<span>*</span>
                          </label>
                          <div className="form-group">
                            <input
                              type="text"
                              name="bedroom_max"
                              className="form-control"
                              placeholder="Bedroom (max)"
                              defaultValue={buyerData.bedroom_max}
                              {...register("bedroom_max", {
                                onChange: (e) => {
                                  setBedRoomMax(e.target.value);
                                },
                                required: "Bedroom (max) is required",
                                validate: {
                                  matchPattern: (v) =>
                                    /^[0-9]\d*$/.test(v) ||
                                    "Please enter valid number",
                                  maxLength: (v) =>
                                    v.length <= 10 ||
                                    "The digit should be less than equal 10",
                                  positiveNumber: (v) =>
                                    parseFloat(v) >= bedRoomMin ||
                                    "The Bedroom (max) should be greater than or equal Bedroom (min)",
                                },
                              })}
                            />
                            {errors.bedroom_max && (
                              <p className="error">
                                {errors.bedroom_max?.message}
                              </p>
                            )}

                            {renderFieldError("bedroom_max")}
                          </div>
                        </div>
                        <div className="col-12 col-sm-6 col-md-6 col-lg-4">
                          <label>
                            Bath (min)<span>*</span>
                          </label>
                          <div className="form-group">
                            <input
                              type="text"
                              name="bath_min"
                              className="form-control"
                              placeholder="Bath (min)"
                              defaultValue={buyerData.bath_min}
                              {...register("bath_min", {
                                onChange: (e) => {
                                  setBathMin(e.target.value);
                                },
                                required: "Bath (min) is required",
                                validate: {
                                  matchPattern: (v) =>
                                    /^[0-9]\d*$/.test(v) ||
                                    "Please enter valid number",
                                  maxLength: (v) =>
                                    v.length <= 10 ||
                                    "The digit should be less than equal 10",
                                  positiveNumber: (v) =>
                                    parseFloat(v) <= bathMax ||
                                    "The Bath (min) should be less than or equal Bath (max)",
                                },
                              })}
                            />
                          </div>
                        </div>
                        <div className="col-12 col-sm-6 col-md-6 col-lg-4">
                          <label>
                            Bath (max)<span>*</span>
                          </label>
                          <div className="form-group">
                            <input
                              type="text"
                              name="bath_max"
                              className="form-control"
                              placeholder="Bath (max)"
                              defaultValue={buyerData.bath_max}
                              {...register("bath_max", {
                                onChange: (e) => {
                                  setBathMax(e.target.value);
                                },
                                required: "Bath (max) is required",
                                validate: {
                                  matchPattern: (v) =>
                                    /^[0-9]\d*$/.test(v) ||
                                    "Please enter valid number",
                                  maxLength: (v) =>
                                    v.length <= 10 ||
                                    "The digit should be less than equal 10",
                                  positiveNumber: (v) =>
                                    parseFloat(v) >= bathMin ||
                                    "The Bath (max) should be greater than or equal Bath (min)",
                                },
                              })}
                            />
                          </div>
                        </div>
                        <div className="col-12 col-sm-6 col-md-6 col-lg-4">
                          <label>
                            Sq Ft Min<span>*</span>
                          </label>
                          <div className="form-group">
                            <input
                              type="text"
                              name="size_min"
                              className="form-control"
                              placeholder="Sq Ft Min"
                              defaultValue={buyerData.size_min}
                              {...register("size_min", {
                                onChange: (e) => {
                                  setSqFtMin(e.target.value);
                                },
                                required: "Sq Ft Min is required",
                                validate: {
                                  matchPattern: (v) =>
                                    /^[0-9]\d*$/.test(v) ||
                                    "Please enter valid number",
                                  maxLength: (v) =>
                                    v.length <= 10 ||
                                    "The digit should be less than equal 10",
                                  positiveNumber: (v) =>
                                    parseFloat(v) <= sqFtMin ||
                                    "The Sq Ft (min) should be less than or equal Sq Ft (max)",
                                },
                              })}
                            />
                            {errors.size_min && (
                              <p className="error">
                                {errors.size_min?.message}
                              </p>
                            )}
                          </div>
                        </div>
                        <div className="col-12 col-sm-6 col-md-6 col-lg-4">
                          <label>
                            Sq Ft Max<span>*</span>
                          </label>
                          <div className="form-group">
                            <input
                              type="text"
                              name="size_max"
                              className="form-control"
                              placeholder="Sq Ft Max"
                              defaultValue={buyerData.size_max}
                              {...register("size_max", {
                                onChange: (e) => {
                                  setSqFtMax(e.target.value);
                                },
                                required: "Sq Ft Max is required",
                                validate: {
                                  matchPattern: (v) =>
                                    /^[0-9]\d*$/.test(v) ||
                                    "Please enter valid number",
                                  maxLength: (v) =>
                                    v.length <= 10 ||
                                    "The digit should be less than equal 10",
                                  positiveNumber: (v) =>
                                    parseFloat(v) >= sqFtMin ||
                                    "The Sq Ft (max) should be greater than or equal Sq Ft (min)",
                                },
                              })}
                            />
                            {errors.size_max && (
                              <p className="error">
                                {errors.size_max?.message}
                              </p>
                            )}
                          </div>
                        </div>
                        <div className="col-12 col-sm-6 col-md-6 col-lg-4">
                          <label>
                            Lot Size Sq Ft (min)<span>*</span>
                          </label>
                          <div className="form-group">
                            <input
                              type="text"
                              name=""
                              className="form-control"
                              placeholder="Lot Size Sq Ft (min)"
                              defaultValue={buyerData.lot_size_min}
                              {...register("lot_size_min", {
                                onChange: (e) => {
                                  setlotSizesqFtMin(e.target.value);
                                },
                                required: "Lot Size Sq Ft (min) is required",
                                validate: {
                                  matchPattern: (v) =>
                                    /^[0-9]\d*$/.test(v) ||
                                    "Please enter valid number",
                                  maxLength: (v) =>
                                    v.length <= 10 ||
                                    "The digit should be less than equal 10",
                                  positiveNumber: (v) =>
                                    parseFloat(v) <= lotSizesqFtMax ||
                                    "The Lot Size Sq Ft (min) should be less than or equal Lot Size Sq Ft (max)",
                                },
                              })}
                            />
                            {errors.lot_size_min && (
                              <p className="error">
                                {errors.lot_size_min?.message}
                              </p>
                            )}
                            {renderFieldError("lot_size_min")}
                          </div>
                        </div>
                        <div className="col-12 col-sm-6 col-md-6 col-lg-4">
                          <label>
                            Lot Size Sq Ft (max)<span>*</span>
                          </label>
                          <div className="form-group">
                            <input
                              type="text"
                              name=""
                              className="form-control"
                              placeholder="Lot Size Sq Ft (max)"
                              defaultValue={buyerData.lot_size_max}
                              {...register("lot_size_max", {
                                onChange: (e) => {
                                  setlotSizesqFtMax(e.target.value);
                                },
                                required: "Lot Size Sq Ft (max) is required",
                                validate: {
                                  matchPattern: (v) =>
                                    /^[0-9]\d*$/.test(v) ||
                                    "Please enter valid number",
                                  maxLength: (v) =>
                                    v.length <= 10 ||
                                    "The digit should be less than equal 10",
                                  positiveNumber: (v) =>
                                    parseFloat(v) >= lotSizesqFtMin ||
                                    "The Lot Size Sq Ft (max) should be greater than or equal Lot Size Sq Ft (min)",
                                },
                              })}
                            />
                            {errors.lot_size_max && (
                              <p className="error">
                                {errors.lot_size_max?.message}
                              </p>
                            )}
                            {renderFieldError("lot_size_max")}
                          </div>
                        </div>
                        <div className="col-12 col-sm-6 col-md-6 col-lg-4">
                          <label>
                            Year Built (min)<span>*</span>
                          </label>
                          <div className="form-group">
                            <Controller
                              control={control}
                              name="build_year_min"
                              rules={{
                                required: "Year Built (min) is required",
                              }}
                              render={({
                                field: { value, onChange, name },
                              }) => (
                                <DatePicker
                                  id="DatePicker"
                                  type="string"
                                  maxDate={new Date()}
                                  className="text-primary text-center form-control"
                                  selected={startDate}
                                  placeholderText="Year Built (Min)"
                                  name="build_year_min"
                                  autoComplete="off"
                                  onChange={(e) => {
                                    onChange(e);
                                    handleCustum(e, "start_date");
                                  }}
                                  showYearPicker
                                  dateFormat="yyyy"
                                  yearItemNumber={9}
                                />
                              )}
                            />
                            {errors.build_year_min && (
                              <p className="error">
                                {errors.build_year_min?.message}
                              </p>
                            )}

                            {renderFieldError("build_year_min")}
                          </div>
                        </div>
                        <div className="col-12 col-sm-6 col-md-6 col-lg-4">
                          <label>
                            Year Built (max)<span>*</span>
                          </label>
                          <div className="form-group">
                            <Controller
                              control={control}
                              name="build_year_max"
                              rules={{
                                required: "Year Built (max) is required",
                              }}
                              render={({
                                field: { value, onChange, name },
                              }) => (
                                <DatePicker
                                  minDate={startDate}
                                  maxDate={new Date()}
                                  id="DatePicker"
                                  type="string"
                                  className="text-primary text-center form-control"
                                  selected={endDate}
                                  name="build_year_max"
                                  placeholderText="Year Built (Max)"
                                  autoComplete="off"
                                  onChange={(e) => {
                                    onChange(e);
                                    handleCustum(e, "end_date");
                                  }}
                                  showYearPicker
                                  dateFormat="yyyy"
                                  yearItemNumber={9}
                                />
                              )}
                            />
                            {errors.build_year_max && (
                              <p className="error">
                                {errors.build_year_max?.message}
                              </p>
                            )}
                            {renderFieldError("build_year_max")}
                          </div>
                        </div>
                        <div className="col-12 col-sm-6 col-md-6 col-lg-4">
                          <label>
                            Stories (Min)<span>*</span>
                          </label>
                          <div className="form-group">
                            <input
                              type="text"
                              name=""
                              className="form-control"
                              placeholder="Enter Stories (Min)"
                              {...register("stories_min", {
                                onChange: (e) => {
                                  setStoriesMin(e.target.value);
                                },
                                required: "Stories (min) is required",
                                validate: {
                                  matchPattern: (v) =>
                                    /^[0-9]\d*$/.test(v) ||
                                    "Please enter valid number",
                                  positiveNumber: (v) =>
                                    parseFloat(v) <= storiesMax ||
                                    "The Stories (min) should be less than or equal Stories (max)",
                                },
                              })}
                            />
                            {errors.stories_min && (
                              <p className="error">
                                {errors.stories_min?.message}
                              </p>
                            )}

                            {renderFieldError("stories_min")}
                          </div>
                        </div>
                        <div className="col-12 col-sm-6 col-md-6 col-lg-4">
                          <label>
                            Stories (Max)<span>*</span>
                          </label>
                          <div className="form-group">
                            <input
                              type="text"
                              name="stories_max"
                              className="form-control"
                              placeholder="Enter Stories (Max)"
                              {...register("stories_max", {
                                onChange: (e) => {
                                  setStoriesMin(e.target.value);
                                },
                                required: "Stories (max) is required",
                                validate: {
                                  matchPattern: (v) =>
                                    /^[0-9]\d*$/.test(v) ||
                                    "Please enter valid number",
                                  positiveNumber: (v) =>
                                    parseFloat(v) <= storiesMax ||
                                    "The Stories (max) should be less than or equal Stories (min)",
                                },
                              })}
                            />
                            {errors.stories_max && (
                              <p className="error">
                                {errors.stories_max?.message}
                              </p>
                            )}

                            {renderFieldError("stories_max")}
                          </div>
                        </div>
                        <div className="col-12 col-sm-6 col-md-6 col-lg-6">
                          <label>
                            Price (Min)<span>*</span>
                          </label>
                          <div className="form-group">
                            <input
                              type="text"
                              name=""
                              className="form-control"
                              placeholder="Price (Min)"
                              defaultValue={buyerData.price_min}
                              {...register("price_min", {
                                onChange: (e) => {
                                  setPriceMin(e.target.value);
                                },
                                required: "Price (min) is required",
                                validate: {
                                  matchPattern: (v) =>
                                    /^[0-9]\d*$/.test(v) ||
                                    "Please enter valid number",
                                  maxLength: (v) =>
                                    v.length <= 10 ||
                                    "The digit should be less than equal 10",
                                  positiveNumber: (v) =>
                                    parseFloat(v) <= priceMax ||
                                    "The Price (min) should be less than or equal Price (max)",
                                },
                              })}
                            />
                            {errors.price_min && (
                              <p className="error">
                                {errors.price_min?.message}
                              </p>
                            )}

                            {renderFieldError("price_min")}
                          </div>
                        </div>
                        <div className="col-12 col-sm-6 col-md-6 col-lg-6">
                          <label>
                            Price (Max)<span>*</span>
                          </label>
                          <div className="form-group">
                            <input
                              type="text"
                              name=""
                              className="form-control"
                              placeholder="Price (Max)"
                              defaultValue={buyerData.price_max}
                              {...register("price_max", {
                                onChange: (e) => {
                                  setPriceMax(e.target.value);
                                },
                                required: "Price (max) is required",
                                validate: {
                                  matchPattern: (v) =>
                                    /^[0-9]\d*$/.test(v) ||
                                    "Please enter valid number",
                                  maxLength: (v) =>
                                    v.length <= 10 ||
                                    "The digit should be less than equal 10",
                                  positiveNumber: (v) =>
                                    parseFloat(v) >= priceMin ||
                                    "The Price (max) should be greater than or equal Price (min)",
                                },
                              })}
                            />
                            {errors.price_max && (
                              <p className="error">
                                {errors.price_max?.message}
                              </p>
                            )}
                          </div>
                        </div>
                        <div className="col-12 col-lg-6">
                          <label>
                            Parking<span>*</span>
                          </label>
                          <div className="form-group">
                            <Controller
                              control={control}
                              name="mls_status"
                              rules={{ required: "State is required" }}
                              render={({
                                field: { value, onChange, name },
                              }) => (
                                <Select
                                  options={parking}
                                  name={name}
                                  //value={state}
                                  closeMenuOnSelect={false}
                                  isClearable={true}
                                  className="select"
                                  placeholder="Select State"
                                  onChange={(e) => {
                                    onChange(e);
                                    handleCustum(e, "state");
                                  }}
                                  isMulti
                                />
                              )}
                            />
                            {errors.parking && (
                              <p className="error">{errors.parking?.message}</p>
                            )}

                            {renderFieldError("parking")}
                          </div>
                        </div>
                        <div className="col-12 col-lg-6">
                          <label>
                            Buyer Type<span>*</span>
                          </label>
                          <div className="form-group">
                            <Controller
                              control={control}
                              name="mls_status"
                              rules={{ required: "State is required" }}
                              render={({
                                field: { value, onChange, name },
                              }) => (
                                <Select
                                  options={buyerType}
                                  name={name}
                                  //value={state}
                                  closeMenuOnSelect={false}
                                  isClearable={true}
                                  className="select"
                                  placeholder="Select State"
                                  onChange={(e) => {
                                    onChange(e);
                                    handleCustum(e, "state");
                                  }}
                                  isMulti
                                />
                              )}
                            />
                            {errors.buyer_type && (
                              <p className="error">
                                {errors.buyer_type?.message}
                              </p>
                            )}

                            {renderFieldError("buyer_type")}
                          </div>
                        </div>
                        <div className="col-12 col-lg-12">
                          <div className="form-group">
                            <label>Location Flaws</label>
                            <div className="form-group">
                              <Controller
                                control={control}
                                name="mls_status"
                                rules={{ required: "State is required" }}
                                render={({
                                  field: { value, onChange, name },
                                }) => (
                                  <Select
                                    options={locationFlaws}
                                    name={name}
                                    //value={state}
                                    closeMenuOnSelect={false}
                                    isClearable={true}
                                    className="select"
                                    placeholder="Select State"
                                    onChange={(e) => {
                                      onChange(e);
                                      handleCustum(e, "state");
                                    }}
                                    isMulti
                                  />
                                )}
                              />
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="column--grid">
                        <div className="grid-template-col">
                          <div className="radio-block-group">
                            <label>Solar</label>
                            <div className="label-container">
                              <input
                                type="radio"
                                name="Solar"
                                checked={buyerData.solar === 1 ? "checked" : ""}
                              />
                              <span>Yes</span>
                            </div>
                            <div className="label-container">
                              <input
                                type="radio"
                                name="Solar"
                                checked={buyerData.solar === 0 ? "checked" : ""}
                              />
                              <span>No</span>
                            </div>
                          </div>
                        </div>
                        <div className="grid-template-col">
                          <div className="radio-block-group">
                            <label>Pool</label>
                            <div className="label-container">
                              <input
                                type="radio"
                                name="Pool"
                                checked={buyerData.pool === 1 ? "checked" : ""}
                              />
                              <span>Yes</span>
                            </div>
                            <div className="label-container">
                              <input
                                type="radio"
                                name="Pool"
                                checked={buyerData.pool === 0 ? "checked" : ""}
                              />
                              <span>No</span>
                            </div>
                          </div>
                        </div>
                        <div className="grid-template-col">
                          <div className="radio-block-group">
                            <label>Septic</label>
                            <div className="label-container">
                              <input
                                type="radio"
                                name="Septic"
                                checked={
                                  buyerData.septic === 1 ? "checked" : ""
                                }
                              />
                              <span>Yes</span>
                            </div>
                            <div className="label-container">
                              <input
                                type="radio"
                                name="Septic"
                                checked={
                                  buyerData.septic === 0 ? "checked" : ""
                                }
                              />
                              <span>No</span>
                            </div>
                          </div>
                        </div>
                        <div className="grid-template-col">
                          <div className="radio-block-group">
                            <label>Well</label>
                            <div className="label-container">
                              <input
                                type="radio"
                                name="Well"
                                checked={buyerData.well === 1 ? "checked" : ""}
                              />
                              <span>Yes</span>
                            </div>
                            <div className="label-container">
                              <input
                                type="radio"
                                name="Well"
                                checked={buyerData.well === 0 ? "checked" : ""}
                              />
                              <span>No</span>
                            </div>
                          </div>
                        </div>
                        <div className="grid-template-col">
                          <div className="radio-block-group">
                            <label>HOA</label>
                            <div className="label-container">
                              <input
                                type="radio"
                                name="HOA"
                                checked={buyerData.hoa === 1 ? "checked" : ""}
                              />
                              <span>Yes</span>
                            </div>
                            <div className="label-container">
                              <input
                                type="radio"
                                name="HOA"
                                checked={buyerData.hoa === 0 ? "checked" : ""}
                              />
                              <span>No</span>
                            </div>
                          </div>
                        </div>
                        <div className="grid-template-col">
                          <div className="radio-block-group">
                            <label>Age restriction</label>
                            <div className="label-container">
                              <input
                                type="radio"
                                name="Age restriction"
                                checked={
                                  buyerData.age_restriction === 0
                                    ? "checked"
                                    : ""
                                }
                              />
                              <span>Yes</span>
                            </div>
                            <div className="label-container">
                              <input
                                type="radio"
                                name="Age restriction"
                                checked={
                                  buyerData.age_restriction === 1
                                    ? "checked"
                                    : ""
                                }
                              />
                              <span>No</span>
                            </div>
                          </div>
                        </div>
                        <div className="grid-template-col">
                          <div className="radio-block-group">
                            <label>Rental Restriction</label>
                            <div className="label-container">
                              <input
                                type="radio"
                                name="Rental Restriction"
                                checked={
                                  buyerData.rental_restriction === 1
                                    ? "checked"
                                    : ""
                                }
                              />
                              <span>Yes</span>
                            </div>
                            <div className="label-container">
                              <input
                                type="radio"
                                name="Rental Restriction"
                                checked={
                                  buyerData.rental_restriction === 0
                                    ? "checked"
                                    : ""
                                }
                              />
                              <span>No</span>
                            </div>
                          </div>
                        </div>
                        <div className="grid-template-col">
                          <div className="radio-block-group">
                            <label>Post-Possession</label>
                            <div className="label-container">
                              <input
                                type="radio"
                                name="Post-Possession"
                                checked={
                                  buyerData.post_possession === 1
                                    ? "checked"
                                    : ""
                                }
                              />
                              <span>Yes</span>
                            </div>
                            <div className="label-container">
                              <input
                                type="radio"
                                name="Post-Possession"
                                checked={
                                  buyerData.post_possession === 0
                                    ? "checked"
                                    : ""
                                }
                              />
                              <span>No</span>
                            </div>
                          </div>
                        </div>
                        <div className="grid-template-col">
                          <div className="radio-block-group">
                            <label>Tenant Conveys</label>
                            <div className="label-container">
                              <input
                                type="radio"
                                name="Tenant Conveys"
                                checked={
                                  buyerData.tenant === 1 ? "checked" : ""
                                }
                              />
                              <span>Yes</span>
                            </div>
                            <div className="label-container">
                              <input
                                type="radio"
                                name="Tenant Conveys"
                                checked={
                                  buyerData.tenant === 0 ? "checked" : ""
                                }
                              />
                              <span>No</span>
                            </div>
                          </div>
                        </div>
                        <div className="grid-template-col">
                          <div className="radio-block-group">
                            <label>Squatters</label>
                            <div className="label-container">
                              <input
                                type="radio"
                                name="Squatters"
                                checked={
                                  buyerData.squatters === 1 ? "checked" : ""
                                }
                              />
                              <span>Yes</span>
                            </div>
                            <div className="label-container">
                              <input
                                type="radio"
                                name="Squatters"
                                checked={
                                  buyerData.squatters === 0 ? "checked" : ""
                                }
                              />
                              <span>No</span>
                            </div>
                          </div>
                        </div>
                        <div className="grid-template-col">
                          <div className="radio-block-group">
                            <label>Building Required</label>
                            <div className="label-container">
                              <input
                                type="radio"
                                name="Building Required"
                                checked={
                                  buyerData.building_required === 1
                                    ? "checked"
                                    : ""
                                }
                              />
                              <span>Yes</span>
                            </div>
                            <div className="label-container">
                              <input
                                type="radio"
                                name="Building Required"
                                checked={
                                  buyerData.building_required === 0
                                    ? "checked"
                                    : ""
                                }
                              />
                              <span>No</span>
                            </div>
                          </div>
                        </div>
                        <div className="grid-template-col">
                          <div className="radio-block-group">
                            <label>Rebuild</label>
                            <div className="label-container">
                              <input
                                type="radio"
                                name="Rebuild"
                                checked={
                                  buyerData.rebuild === 1 ? "checked" : ""
                                }
                              />
                              <span>Yes</span>
                            </div>
                            <div className="label-container">
                              <input
                                type="radio"
                                name="Rebuild"
                                checked={
                                  buyerData.rebuild === 0 ? "checked" : ""
                                }
                              />
                              <span>No</span>
                            </div>
                          </div>
                        </div>
                        <div className="grid-template-col">
                          <div className="radio-block-group">
                            <label>Foundation Issues</label>
                            <div className="label-container">
                              <input
                                type="radio"
                                name="Foundation Issues"
                                checked={
                                  buyerData.foundation_issues === 1
                                    ? "checked"
                                    : ""
                                }
                              />
                              <span>Yes</span>
                            </div>
                            <div className="label-container">
                              <input
                                type="radio"
                                name="Foundation Issues"
                                checked={
                                  buyerData.foundation_issues === 0
                                    ? "checked"
                                    : ""
                                }
                              />
                              <span>No</span>
                            </div>
                          </div>
                        </div>
                        <div className="grid-template-col">
                          <div className="radio-block-group">
                            <label>Mold</label>
                            <div className="label-container">
                              <input
                                type="radio"
                                name="Mold"
                                checked={buyerData.mold === 1 ? "checked" : ""}
                              />
                              <span>Yes</span>
                            </div>
                            <div className="label-container">
                              <input
                                type="radio"
                                name="Mold"
                                checked={buyerData.mold === 0 ? "checked" : ""}
                              />
                              <span>No</span>
                            </div>
                          </div>
                        </div>
                        <div className="grid-template-col">
                          <div className="radio-block-group">
                            <label>Fire Damaged</label>
                            <div className="label-container">
                              <input
                                type="radio"
                                name="Fire Damaged"
                                checked={
                                  buyerData.fire_damaged === 1 ? "checked" : ""
                                }
                              />
                              <span>Yes</span>
                            </div>
                            <div className="label-container">
                              <input
                                type="radio"
                                name="Fire Damaged"
                                checked={
                                  buyerData.fire_damaged === 0 ? "checked" : ""
                                }
                              />
                              <span>No</span>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="submit-btn">
                        <button type="submit" className="btn btn-fill">
                          Submit Now!
                        </button>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <Footer />
    </>
  );
};
export default EditBuyerProfile;
